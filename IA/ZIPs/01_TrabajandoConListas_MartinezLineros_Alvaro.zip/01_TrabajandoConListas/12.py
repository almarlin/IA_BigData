cadenas = list(["asf","asdfasf","fgh","fert","hd","bcv","b"])
tot=""

for str in cadenas:
    tot +=str
print(tot)