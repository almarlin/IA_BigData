frutas = list(["manzana", "pera", "uva", "melocoton"])

frutas.reverse()
frutas.pop()
frutas.reverse()
print(frutas)