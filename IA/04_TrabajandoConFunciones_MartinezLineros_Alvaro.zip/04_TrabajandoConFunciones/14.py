suma = lambda a, b: a + b

num1 = int(input("Introduce un número: "))
num2 = int(input("Introduce otro número: "))

print(f"{num1} + {num2} = {suma(num1,num2)}")
