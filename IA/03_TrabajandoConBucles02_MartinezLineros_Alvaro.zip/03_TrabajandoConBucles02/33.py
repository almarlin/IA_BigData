inicio = int(input("Inicio del rango: "))
fin = int(input("Fin del rango: "))

primos = list()

for num in range(inicio,fin):
    es_primo = True
    if num < 2:
        es_primo = False
    else:
        for i in range(2, num - 1):
            if num % i == 0:
                es_primo = False 
    if es_primo:
        primos.append(num)

print(f"Los numeros primos entre {inicio} y {fin} son: {primos}")