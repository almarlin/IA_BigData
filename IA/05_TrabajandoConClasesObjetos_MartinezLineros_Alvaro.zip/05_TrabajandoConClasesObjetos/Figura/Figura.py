class Figura:
    def __init__(self,color,tipo):
        self.color = color
        self.tipo = tipo

    def calcularArea(self):
        return
    
    def calcularPerimetro(self):
        return