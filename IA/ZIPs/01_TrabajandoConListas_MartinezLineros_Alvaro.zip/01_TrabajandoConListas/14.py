letras = list(["a","b","c","d","e","f","g"])

print(letras.index("c"))