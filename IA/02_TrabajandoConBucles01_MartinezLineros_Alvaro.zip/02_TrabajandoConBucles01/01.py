for num in range(1,100):
    if num % 2 == 0:
        print(num)
