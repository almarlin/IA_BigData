booleanos = list([True, True, False, True, False])

print(all(booleanos))