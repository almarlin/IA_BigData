colores = list(["azul", "verde", "amarillo", "rojo"])

colores.insert(2,"Cian")
print(colores)