numeros = list([234,134,12,0,56,7,32,35,2])

print("Antes de del:", numeros)

del numeros[0:5]

print("Después de del:", numeros)