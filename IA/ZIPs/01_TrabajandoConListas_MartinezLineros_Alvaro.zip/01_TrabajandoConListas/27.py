ciudades = list(["Budapest", "Sevilla", "Milan", "Florencia"])

ciudades.pop(-1)
print(ciudades)