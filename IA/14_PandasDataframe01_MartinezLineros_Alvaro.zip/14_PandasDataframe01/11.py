import pandas as pd

df = pd.read_excel("datos_alumnos.xlsx")

print(df.head())

