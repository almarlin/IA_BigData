numeros = list([1,2,3,4,5])

numeros.remove(3)
print(numeros)