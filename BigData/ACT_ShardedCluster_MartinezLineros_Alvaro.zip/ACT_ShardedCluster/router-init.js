sh.addShard("shard1/mongo-shard1a:27017")
sh.addShard("shard1/mongo-shard1b:27017")
sh.addShard("shard1/mongo-shard1c:27017")

sh.addShard("shard2/mongo-shard2a:27017")
sh.addShard("shard2/mongo-shard2b:27017")
sh.addShard("shard2/mongo-shard2c:27017")

sh.addShard("shard3/mongo-shard3a:27017")
sh.addShard("shard3/mongo-shard3b:27017")
sh.addShard("shard3/mongo-shard3c:27017")