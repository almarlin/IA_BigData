import pandas as pd

df = pd.read_excel("datos_alumnos.xlsx")

df.to_csv("datos_alumnos12.csv")