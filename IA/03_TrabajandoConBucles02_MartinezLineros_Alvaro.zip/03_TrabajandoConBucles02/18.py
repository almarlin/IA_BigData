num = int(input("Ingresa un numero: "))

if num in range(1,100):
    print("Numero en el rango 1-100")
else:
    print("Numero fuera del rango 1-100")