colores = list(["Azul","Verde","Cian","Morado"])
colores2 = colores.copy()

print(colores2)