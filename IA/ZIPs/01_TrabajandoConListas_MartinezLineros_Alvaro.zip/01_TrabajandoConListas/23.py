booleanos = list([True, True, False, True, False])

print(any(booleanos))