numeros1 = list([1,2,3,4,5])
numeros2 = list([6,7,8,9,0])

numeros1.extend(numeros2)
print(numeros1)