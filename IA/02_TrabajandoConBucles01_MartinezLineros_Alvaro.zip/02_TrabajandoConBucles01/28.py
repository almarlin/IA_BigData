n = int(input("Introduce el tamaño del cuadrado (N): "))

for i in range(n):
    for j in range(n):
        print("*", end=' ')  
    print() 
