numeros = list([1,2,3,4,5])

print("Tercer número de la lista",numeros[3])
