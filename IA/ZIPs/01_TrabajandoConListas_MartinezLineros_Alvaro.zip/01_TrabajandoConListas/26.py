numeros = list([3,6,8,7,5,95,4,3,23])

print(numeros[2:6])