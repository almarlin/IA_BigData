tupla = (1,2,3,4)

lista = list(tupla)

lista.append(5)

print(lista)