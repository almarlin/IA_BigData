rev = lambda cadena: cadena[::-1]

cadena = input("Introduce una cadena: ")

print(f"La cadena invertida es: {rev(cadena)}")