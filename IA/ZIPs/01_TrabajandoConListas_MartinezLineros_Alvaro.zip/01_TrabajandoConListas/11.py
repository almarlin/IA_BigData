numeros1 = list([1,2,3,4,5])
numeros2 = list([6,7,8,9,10])

numeros3 = numeros1 + numeros2
print(numeros3)