palabras = list(["hola","programación","bigdata","ia"])

mayusculas = list(map(str.upper,palabras))

print("Palabras: ",palabras)
print("Mayúsculas: ",mayusculas)