num = int(input("Introduce un número: "))

tot = num

for i in range(1,num):
    tot = tot + i

print(f"El cálculo es: {tot}")