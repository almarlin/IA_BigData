ciudades = list(["Budapest", "Sevilla", "Milan", "Florencia"])
colores = list(["Azul","Verde","Cian","Morado"])
numeros = list([234,134,12,0,56,7,32,35,2])

listas = list([ciudades,colores,numeros])

for lista in listas:
    for item in lista:
        print(item)