animales = list(["perro", "gato", "cocodrilo", "tortuga", "conejo"])

print(("tortuga" in animales))