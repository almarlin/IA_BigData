numero = int(input("Introduce un numero: "))

numeroStr = str(numero)
i = 0

while i < len(numeroStr):
    i += 1

print(f"El total es: {i} digitos")