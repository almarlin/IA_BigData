numeros = list([3,5,2,6,1,8])

numeros.sort()
print(numeros)