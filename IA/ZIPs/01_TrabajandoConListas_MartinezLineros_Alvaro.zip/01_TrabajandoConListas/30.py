numeros = list([234,134,12,0,56,7,32,35,2])

sortedNumeros = sorted(numeros)
print(sortedNumeros)
print(numeros)