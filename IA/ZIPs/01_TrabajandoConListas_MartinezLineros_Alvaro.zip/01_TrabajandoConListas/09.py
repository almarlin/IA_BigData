nombres = list(["Alvaro", "Jose", "Javi", "Juan", "Jose", "Pedro", "Pepe"])

print(nombres.count("Jose"))
