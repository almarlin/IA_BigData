cadena = "adsfasdfasdfaf"

print(list(cadena))