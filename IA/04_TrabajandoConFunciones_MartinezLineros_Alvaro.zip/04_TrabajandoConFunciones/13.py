num = int(input("Introduce un número: "))

cuad = lambda x: x**2

print(f"El cuadrado de {num} es {cuad(num)}")
