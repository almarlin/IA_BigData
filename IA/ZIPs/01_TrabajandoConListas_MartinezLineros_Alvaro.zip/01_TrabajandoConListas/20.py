numeros = list([1, 2, 3])

result = [el * 4 for el in numeros]

print(result)
