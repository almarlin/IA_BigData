nombres = list(["Paul","Jessica","Duncan","Thufir","Gurney"])

nombresOrd = sorted(nombres,key=len)

print("Lista original: ",nombres)
print("Ordenada: ",nombresOrd)