import random

dado1 = random.randint(1,6)
dado2 = random.randint(1,6)

print(f"El primer dado muestra {dado1}, el segundo {dado2}. La suma total es {dado1 + dado2}")