i = 5
total = 1
while i > 0:
    total *= i
    i -= 1

print("Factorial: ", total)
