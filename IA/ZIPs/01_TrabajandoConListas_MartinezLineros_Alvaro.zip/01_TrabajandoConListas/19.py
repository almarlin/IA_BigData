nombres = list(["Alvaro", "Jose", "Javi", "Juan", "Jose", "Pedro", "Pepe"])

nombres.clear()
print(nombres)