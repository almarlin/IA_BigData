num = int(input("Introduce un numero: "))

if num % 2 == 0:
    print(f"El numero {num} es par")
else:
    print(f"El numero {num} es impar")