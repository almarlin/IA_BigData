ciudades = list(["Budapest", "Sevilla", "Milan", "Florencia"])

for index, ciudad in enumerate(ciudades):
    print(index, ":", ciudad)
