nombres = list(["Alvaro", "Jose", "Javi", "Juan", "Jose", "Pedro", "Pepe"])
colores = list(["Azul","Verde","Cian","Morado"])
numeros = list([1,2,3,4,5])

listas = list([nombres,colores,numeros])

print(listas[1][1])