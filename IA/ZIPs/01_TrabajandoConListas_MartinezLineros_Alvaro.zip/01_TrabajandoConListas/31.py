lista = list([1,"iu","ads",5,"lskf",6,3])

print("Segundo elemento: "+lista[1])