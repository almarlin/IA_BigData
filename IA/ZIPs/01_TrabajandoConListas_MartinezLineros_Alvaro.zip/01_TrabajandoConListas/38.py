numeros = list([234, 2, 2, 134, 12, 2, 0, 56, 7, 32, 35, 2])

print("Con duplicados:", numeros)

sinDuplicados = list(set(numeros))

print("Sin duplicados:", sinDuplicados)
