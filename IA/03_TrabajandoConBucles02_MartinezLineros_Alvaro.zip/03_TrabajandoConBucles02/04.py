filas=int(input("Introduce las filas del patrón: "))

for i in range(filas,0,-1):
     print('*' * i)
