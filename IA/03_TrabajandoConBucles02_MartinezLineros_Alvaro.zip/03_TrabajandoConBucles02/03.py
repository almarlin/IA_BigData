filas=int(input("Introduce las filas del patrón: "))

for i in range(1, filas + 1):
        print('*' * i)


