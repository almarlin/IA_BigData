for n in range(1,11):
    print(f"\nTabla del {n}")
    for n2 in range(1,11):
        print(f"{n} * {n2} = {n*n2}")