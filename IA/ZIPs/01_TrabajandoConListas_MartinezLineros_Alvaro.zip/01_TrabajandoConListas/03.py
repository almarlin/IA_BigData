paises = list(["España", "Italia", "Hungría", "Portugal", "Vietnam"])
paises[1] = "Camboya"
print(paises)