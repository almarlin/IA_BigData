cadenas = list(["asd","hdh","wer","dfg","h","rdhs","d"])

print(", ".join(cadenas))